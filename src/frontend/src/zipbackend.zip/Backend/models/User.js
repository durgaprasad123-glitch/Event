import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  userName: String,
  userEmail: { type: String, unique: true },
  userPassword: String,
  linkedinProfile: String,
  events: Array,
  cateringName: String,
  menuDetails: String,
  functionHallName: String,
  hallCapacity: Number,
});

// Export the User model
const User = mongoose.model('User', userSchema);
export default User; // Make sure to have this line
