// backend/routes/auth.js

import express from 'express';
import bcrypt from 'bcrypt'; // Import bcrypt for hashing passwords
import User from '../models/User.js'; // Ensure this points to your User model

const router = express.Router();

// Registration Route
router.post('/register', async (req, res) => {
  const { userName, userEmail, userPassword, linkedinProfile, events, cateringName, menuDetails, functionHallName, hallCapacity } = req.body;

  try {
    // Check if the user already exists
    const existingUser = await User.findOne({ userEmail });
    if (existingUser) {
      return res.status(400).json({ message: 'User already exists' });
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(userPassword, 10);

    // Create a new user instance
    const newUser = new User({
      userName,
      userEmail,
      userPassword: hashedPassword, // Store the hashed password
      linkedinProfile,
      events,
      cateringName,
      menuDetails,
      functionHallName,
      hallCapacity,
    });

    // Save the user to the database
    await newUser.save();
    res.status(201).json({ message: 'User registered successfully!' });
  } catch (error) {
    res.status(500).json({ message: 'Registration failed', error: error.message });
  }
});

// Login Route
router.post('/login', async (req, res) => {
  const { userEmail, userPassword } = req.body;

  try {
    // Find the user by email
    const user = await User.findOne({ userEmail });
    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    // Compare the entered password with the hashed password
    const isPasswordValid = await bcrypt.compare(userPassword, user.userPassword);
    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    res.status(200).json({ message: 'Login successful' });
  } catch (error) {
    res.status(500).json({ message: 'Login failed', error: error.message });
  }
});

export default router;